package com.example.dalathasfarm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DalathasfarmApplicationTests {

	@Test
	void contextLoads() {
	}

}
